//
// Created by matth on 4/21/2020.
//

#include "Cell.h"

Cell::Cell():contents(open),viewStatus(newCell),leeWt(-1),akersWt(d),cost(1) {

}
